import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import re
import pandas as pd
import pickle
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB




# Assuming these are your custom feature extraction methods,
# imported from their respective modules.
from feature_extraction import extract_BoW_features1, extract_BoW_features2

# Function to train CountVectorizer
def train_count_vectorizer(x_train):
    texts = [text[1] for text in x_train]
    vectorizer = CountVectorizer()
    vectorizer.fit_transform(texts)
    return vectorizer

# Function to train TfidfVectorizer
def train_other_vectorizer(x_train):
    texts = [text[1] for text in x_train]
    vectorizer = TfidfVectorizer()
    vectorizer.fit_transform(texts)
    return vectorizer

# Load your training data
x_train_df = pd.read_csv('/Users/sammiller/Desktop/CS135/projA-release/data_reviews/x_train.csv')
y_train_df = pd.read_csv('/Users/sammiller/Desktop/CS135/projA-release/data_reviews/y_train.csv')
y_train = y_train_df['is_positive_sentiment']
x_train = x_train_df.values.tolist()

# Train vectorizers
vectorizer = train_count_vectorizer(x_train)
vectorizer_Tfid = train_other_vectorizer(x_train)

# Save vectorizers
with open('vectorizer1.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)
    
with open('vectorizer2.pkl', 'wb') as f:
    pickle.dump(vectorizer_Tfid, f)

# Feature extraction for each model
X_train1 = extract_BoW_features1(x_train)
X_train2 = extract_BoW_features2(x_train)

# Initialize and train your models with the respective feature sets
classifier1 = LogisticRegression(max_iter=1000)
classifier2 = MultinomialNB()

classifier1.fit(X_train1, y_train)
classifier2.fit(X_train2, y_train)

# Save classifiers
with open('classifier1.pkl', 'wb') as f:
    pickle.dump(classifier1, f)

with open('classifier2.pkl', 'wb') as f:
    pickle.dump(classifier2, f)
