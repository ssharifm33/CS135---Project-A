import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import pandas as pd
import pickle
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import GridSearchCV

# Assuming these are your custom feature extraction methods,
# imported from their respective modules.
from feature_extraction import extract_BoW_features1, extract_BoW_features2

def train_count_vectorizer(x_train):
    texts = [text[1] for text in x_train]
    vectorizer = CountVectorizer()
    vectorizer.fit_transform(texts)
    return vectorizer

def train_other_vectorizer(x_train):
    texts = [text[1] for text in x_train]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2))
    vectorizer.fit_transform(texts)
    return vectorizer

# Load your training data
x_train_df = pd.read_csv('/Users/sammiller/Desktop/CS135/projA-release/data_reviews/x_train.csv')
y_train_df = pd.read_csv('/Users/sammiller/Desktop/CS135/projA-release/data_reviews/y_train.csv')
y_train = y_train_df['is_positive_sentiment']
x_train = x_train_df.values.tolist()

# Train vectorizers
vectorizer = train_count_vectorizer(x_train)
vectorizer_Tfid = train_other_vectorizer(x_train)

# Save vectorizers
with open('vectorizer1.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)
    
with open('vectorizer2.pkl', 'wb') as f:
    pickle.dump(vectorizer_Tfid, f)

# Feature extraction for each model
X_train1 = extract_BoW_features1(x_train)
X_train2 = extract_BoW_features2(x_train)

# Define the parameter grid for LogisticRegression
param_grid_lr = {
    'C': np.logspace(-4, 4, 20),
    'penalty': ['l1', 'l2'],
}

# Initialize the GridSearchCV object for LogisticRegression
grid_search_lr = GridSearchCV(LogisticRegression(max_iter=1000, solver='liblinear'), param_grid_lr, cv=5, scoring='accuracy', verbose=1)

# Fit GridSearchCV for LogisticRegression
grid_search_lr.fit(X_train1, y_train)

# Define the parameter grid for MultinomialNB
param_grid_nb = {
    'alpha': np.linspace(0.1, 2, 20),
}

# Initialize the GridSearchCV object for MultinomialNB
grid_search_nb = GridSearchCV(MultinomialNB(), param_grid_nb, cv=5, scoring='accuracy', verbose=1)

# Fit GridSearchCV for MultinomialNB
grid_search_nb.fit(X_train2, y_train)

# Access the best set of parameters and retrain the classifiers
best_lr = LogisticRegression(**grid_search_lr.best_params_)
best_lr.fit(X_train1, y_train)

best_nb = MultinomialNB(**grid_search_nb.best_params_)
best_nb.fit(X_train2, y_train)

# Save the optimized classifiers
with open('classifier1.pkl', 'wb') as f:
    pickle.dump(best_lr, f)

with open('classifier2.pkl', 'wb') as f:
    pickle.dump(best_nb, f)
