import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import pandas as pd
import pickle
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt


# Assuming these are your custom feature extraction methods,
# imported from their respective modules.
from feature_extraction import extract_BoW_features1, extract_BoW_features2

def train_count_vectorizer(x_train):
    texts = [text[1] for text in x_train]
    vectorizer = CountVectorizer()
    vectorizer.fit_transform(texts)
    return vectorizer

def train_other_vectorizer(x_train):
    texts = [text[1] for text in x_train]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2))
    vectorizer.fit_transform(texts)
    return vectorizer

# Load your training data
x_train_df = pd.read_csv('/Users/sammiller/Desktop/CS135/projA-release/data_reviews/x_train.csv')
y_train_df = pd.read_csv('/Users/sammiller/Desktop/CS135/projA-release/data_reviews/y_train.csv')
y_train = y_train_df['is_positive_sentiment']
x_train = x_train_df.values.tolist()

# Train vectorizers
vectorizer = train_other_vectorizer(x_train)
vectorizer_Tfid = train_other_vectorizer(x_train)

# Save vectorizers
with open('vectorizer1.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)
    
with open('vectorizer2.pkl', 'wb') as f:
    pickle.dump(vectorizer_Tfid, f)

# Feature extraction for each model
X_train1 = extract_BoW_features1(x_train)
X_train2 = extract_BoW_features2(x_train)

# Define the parameter grid for LogisticRegression
param_grid_lr = {
    'C': np.logspace(-7, 7, 20),
    'penalty': ['l1', 'l2'],
}

# Initialize the GridSearchCV object for LogisticRegression
#grid_search_lr = GridSearchCV(LogisticRegression(max_iter=1000, solver='liblinear'), param_grid_lr, cv=5, scoring='roc_auc', verbose=1)
grid_search_lr = GridSearchCV(LogisticRegression(max_iter=1000, solver='liblinear'), 
                              param_grid_lr, cv=5, scoring='roc_auc', verbose=1, return_train_score=True)

# Fit GridSearchCV for LogisticRegression
grid_search_lr.fit(X_train1, y_train)

# Define the parameter grid for MultinomialNB
param_grid_nb = {
    'alpha': np.linspace(0.1, 2, 20),
}

# Initialize the GridSearchCV object for MultinomialNB
grid_search_nb = GridSearchCV(MultinomialNB(), param_grid_nb, cv=5, scoring='roc_auc', verbose=1)

# Fit GridSearchCV for MultinomialNB
grid_search_nb.fit(X_train2, y_train)

# Access the best set of parameters and retrain the classifiers
best_lr = LogisticRegression(**grid_search_lr.best_params_)


best_lr.fit(X_train1, y_train)

print(grid_search_lr.best_params_)

best_nb = MultinomialNB(**grid_search_nb.best_params_)
best_nb.fit(X_train2, y_train)

# Save the optimized classifiers
with open('classifier1.pkl', 'wb') as f:
    pickle.dump(best_lr, f)
    

# After fitting the GridSearchCV object
results_lr = pd.DataFrame(grid_search_lr.cv_results_)

# Get mean scores and the standard deviation of scores
mean_train_scores = results_lr['mean_train_score']
std_train_scores = results_lr['std_train_score']
mean_test_scores = results_lr['mean_test_score']
std_test_scores = results_lr['std_test_score']

tested_C_values = results_lr['param_C'].astype(np.float64)
penalties = results_lr['param_penalty']

# Plotting for L1 penalty
plt.figure(figsize=(10, 6))
penalty = 'l1'
penalty_mask = results_lr['param_penalty'] == penalty
penalty_C_values = tested_C_values[penalty_mask]
penalty_mean_train_scores = mean_train_scores[penalty_mask]
penalty_mean_test_scores = mean_test_scores[penalty_mask]
penalty_std_train_scores = std_train_scores[penalty_mask]
penalty_std_test_scores = std_test_scores[penalty_mask]

plt.errorbar(penalty_C_values, penalty_mean_train_scores, yerr=penalty_std_train_scores,
             label=f'Training Score ({penalty.upper()})', fmt='o-', capsize=5)
plt.errorbar(penalty_C_values, penalty_mean_test_scores, yerr=penalty_std_test_scores,
             label=f'Validation Score ({penalty.upper()})', fmt='o-', capsize=5)

plt.xscale('log')
plt.xlabel('C (Inverse of Regularization Strength)')
plt.ylabel('Mean ROC AUC Score')
plt.title('Logistic Regression Hyperparameter Tuning Results: L1 Penalty')
plt.legend()
plt.grid(True)
plt.show()

# Plotting for L2 penalty
plt.figure(figsize=(10, 6))
penalty = 'l2'
penalty_mask = results_lr['param_penalty'] == penalty
penalty_C_values = tested_C_values[penalty_mask]
penalty_mean_train_scores = mean_train_scores[penalty_mask]
penalty_mean_test_scores = mean_test_scores[penalty_mask]
penalty_std_train_scores = std_train_scores[penalty_mask]
penalty_std_test_scores = std_test_scores[penalty_mask]

plt.errorbar(penalty_C_values, penalty_mean_train_scores, yerr=penalty_std_train_scores,
             label=f'Training Score ({penalty.upper()})', fmt='o-', capsize=5)
plt.errorbar(penalty_C_values, penalty_mean_test_scores, yerr=penalty_std_test_scores,
             label=f'Validation Score ({penalty.upper()})', fmt='o-', capsize=5)

plt.xscale('log')
plt.xlabel('C (Inverse of Regularization Strength)')
plt.ylabel('Mean ROC AUC Score')
plt.title('Logistic Regression Hyperparameter Tuning Results: L2 Penalty')
plt.legend()
plt.grid(True)
plt.show()









with open('classifier2.pkl', 'wb') as f:
    pickle.dump(best_nb, f)
